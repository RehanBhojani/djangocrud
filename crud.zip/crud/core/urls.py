from django.urls import path
from .views import Home, add_student, delete_student, edit_student

urlpatterns = [
    path('', Home.as_view(), name="home"),
    path('add-student/', add_student.as_view(), name='add-student'),
    path('delete-student/', delete_student.as_view(), name='delete-student'),
    path('edit-student/<int:id>/', edit_student.as_view(), name='edit-student')
]